import React from "react";

function ProductCard( props ){
    return (
        <div key={props.heading} className="card mx-auto col-4">
        <img className="card-img-top" src={props.image} alt={props.description} title={props.description} />
        <div className="card-body">
        <h4 className="card-title">{props.heading}</h4>
        <p className="card-text">{props.price}</p>

        {/* <ProductAction name={props.name} /> */}
        </div>
    </div>
    )
}

export default ProductCard;