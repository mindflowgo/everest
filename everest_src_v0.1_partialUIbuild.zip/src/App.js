import React from 'react';
import { BrowserRouter as Router, Route } from "react-router-dom";

import NavBar from './components/NavBar';
import ProductListPage from './components/ProductListPage';
import ProductInfoPage from './components/ProductInfoPage';
import SettingsPage from './components/SettingsPage';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
    <div className="App">
        <NavBar />
        <div class="container">
          <Route exact path={["/","/productlist"]} component={ProductListPage} />
          <Route exact path="/productinfo" component={ProductInfoPage} />
          <Route exact path="/settings" component={SettingsPage} />
        </div>

        <Footer />
    </div>
    </Router>
  );
}

export default App;
