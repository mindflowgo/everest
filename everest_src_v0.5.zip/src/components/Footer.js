import React from "react";

function Footer( props ){
    return (
        <div class="footer">(c) 2020 The Everest Team</div>
    )
}

export default Footer;