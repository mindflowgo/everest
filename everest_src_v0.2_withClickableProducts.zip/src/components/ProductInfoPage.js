import React from "react";

function ProductInfoPage( props ){
    return (
        <>[ProductInfoPage]</>
    )
}

export default ProductInfoPage;