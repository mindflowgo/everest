import React from "react";
import ProductCard from "./ProductCard";
import products from "./products.json";

function ProductListPage( props ){
    return (
        <div class="row">
        {products.map( product=><ProductCard {...product} />)}
        </div>
    )
}

export default ProductListPage;
