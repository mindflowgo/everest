import React from "react";
import products from "./products.json";
import { useParams } from "react-router-dom";
import RatingBar from "./RatingBar";

function ProductInfoPage( props ){
    // const { id } = props.match.params;
    const { id } = useParams();
    console.log( `[ProductInfoPage] id=${id}`, props );

    const showProduct = products.filter( product=>product.id===id )[0];

    return (
        <div class='container'>
            <div class='row'>
                <div class='col-4'>
                    <img src={showProduct.image} class='img-thumbnail' />
                </div>
                <div class='col-8'>
                    <h1>{showProduct.heading}</h1>
                    <h2>{showProduct.price}</h2>

                    <RatingBar rating={showProduct.rating} />

                    {/* <ProductAction /> */}
                    <button class="btn btn-lg btn-primary"><i class="fas fa-cart-plus"></i></button>
                    <button class="btn btn-lg btn-secondary">[leave-review]</button>
                </div>
                {showProduct.description}
                <hr />
                {/* <ProductReviews /> */}
                <b>Przemek</b><br />
                Awesome fridge, keeps all my food cool 
                
            </div>
        </div>
    )
}

export default ProductInfoPage;