import React from "react";

function SettingsPage( props ){
    return (
        <>[SettingsPage]</>
    )
}

export default SettingsPage;